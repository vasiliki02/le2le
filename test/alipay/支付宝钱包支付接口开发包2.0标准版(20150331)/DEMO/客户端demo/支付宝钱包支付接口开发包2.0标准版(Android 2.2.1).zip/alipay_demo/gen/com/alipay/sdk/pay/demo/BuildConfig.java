/** Automatically generated file. DO NOT MODIFY */
package com.alipay.sdk.pay.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}